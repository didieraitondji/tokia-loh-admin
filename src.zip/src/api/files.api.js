import api from "./client";

/**
 * FilesAPI — upload et gestion des fichiers media.
 * ⚠️  Nouveau en v2 — à utiliser pour uploader les images
 *     produits, catégories et publicités au lieu de passer des URLs.
 *
 * GET    /shop/files/
 * POST   /shop/files/      (multipart/form-data)
 * GET    /shop/files/:id/
 * DELETE /shop/files/:id/
 *
 * Workflow recommandé :
 *   1. upload(file)  → reçoit { id, url, ... }
 *   2. Utiliser l'URL retournée dans product.image, category.icon, etc.
 */
class FilesAPI {
  /** Liste tous les fichiers uploadés. */
  list() {
    return api.get("/shop/files/");
  }

  /**
   * Upload un fichier.
   * @param {File} file — objet File du navigateur
   */
  upload(file) {
    const formData = new FormData();
    formData.append("file", file);
    return api.post("/shop/files/", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });
  }

  /**
   * Détail d'un fichier.
   * @param {string} id — UUID
   */
  detail(id) {
    return api.get(`/shop/files/${id}/`);
  }

  /**
   * Supprime un fichier.
   * @param {string} id — UUID
   */
  delete(id) {
    return api.delete(`/shop/files/${id}/`);
  }
}

export const filesAPI = new FilesAPI();
