import { useState, useEffect, useCallback } from "react";
import { citiesAPI } from "../api/cities.api";

const USE_MOCK = true; // 🔧 Passer à false quand l'API est prête

// ── Mock villes ───────────────────────────────────────────────
const MOCK_VILLES = [
  {
    id: "ville-001",
    name: "Cotonou",
    delivery_price: 500,
    created_at: "2025-01-10T00:00:00Z",
  },
  {
    id: "ville-002",
    name: "Porto-Novo",
    delivery_price: 800,
    created_at: "2025-01-11T00:00:00Z",
  },
  {
    id: "ville-003",
    name: "Parakou",
    delivery_price: 1500,
    created_at: "2025-01-12T00:00:00Z",
  },
  {
    id: "ville-004",
    name: "Bohicon",
    delivery_price: 1000,
    created_at: "2025-01-13T00:00:00Z",
  },
  {
    id: "ville-005",
    name: "Abomey-Calavi",
    delivery_price: 600,
    created_at: "2025-01-14T00:00:00Z",
  },
  {
    id: "ville-006",
    name: "Natitingou",
    delivery_price: 2000,
    created_at: "2025-01-15T00:00:00Z",
  },
];

/**
 * useVilles — gère la liste et le CRUD des villes de livraison.
 *
 * Usage :
 *   const { villes, loading, error, create, update, remove } = useVilles();
 *
 * Usage détail :
 *   const { ville, loading } = useVilles({ id: 'uuid-xxx' });
 */
export const useVilles = (options = {}) => {
  const { id = null } = options;

  const [villes, setVilles] = useState([]);
  const [ville, setVille] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // ── Fetch liste ───────────────────────────────────────────
  const fetchAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      if (USE_MOCK) {
        await new Promise((r) => setTimeout(r, 400));
        setVilles(MOCK_VILLES);
      } else {
        const { data } = await citiesAPI.list();
        const list = Array.isArray(data) ? data : (data.results ?? []);
        setVilles(list);
      }
    } catch (err) {
      setError(err.message ?? "Erreur lors du chargement des villes");
    } finally {
      setLoading(false);
    }
  }, []);

  // ── Fetch détail ──────────────────────────────────────────
  const fetchOne = useCallback(async (villeId) => {
    setLoading(true);
    setError(null);
    try {
      if (USE_MOCK) {
        await new Promise((r) => setTimeout(r, 400));
        setVille(MOCK_VILLES.find((v) => v.id === villeId) ?? null);
      } else {
        const { data } = await citiesAPI.detail(villeId);
        setVille(data);
      }
    } catch (err) {
      setError(err.message ?? "Erreur lors du chargement de la ville");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (id) fetchOne(id);
    else fetchAll();
  }, [id, fetchAll, fetchOne]);

  // ── Créer ─────────────────────────────────────────────────
  const create = async (payload) => {
    if (USE_MOCK) {
      const newVille = {
        ...payload,
        id: `ville-${Date.now()}`,
        created_at: new Date().toISOString(),
      };
      setVilles((prev) => [...prev, newVille]);
      return newVille;
    }
    const { data } = await citiesAPI.create(payload);
    setVilles((prev) => [...prev, data]);
    return data;
  };

  // ── Modifier ──────────────────────────────────────────────
  const update = async (villeId, payload) => {
    // Mise à jour optimiste
    setVilles((prev) =>
      prev.map((v) => (v.id === villeId ? { ...v, ...payload } : v)),
    );
    setVille((prev) => (prev?.id === villeId ? { ...prev, ...payload } : prev));

    if (!USE_MOCK) {
      try {
        const { data } = await citiesAPI.update(villeId, payload);
        setVilles((prev) => prev.map((v) => (v.id === villeId ? data : v)));
        setVille((prev) => (prev?.id === villeId ? data : prev));
        return data;
      } catch (err) {
        setError(err.message ?? "Erreur mise à jour ville");
        fetchAll();
        throw err;
      }
    }
  };

  // ── Supprimer ─────────────────────────────────────────────
  const remove = async (villeId) => {
    setVilles((prev) => prev.filter((v) => v.id !== villeId));

    if (!USE_MOCK) {
      try {
        await citiesAPI.delete(villeId);
      } catch (err) {
        setError(err.message ?? "Erreur suppression ville");
        fetchAll(); // Rollback
        throw err;
      }
    }
  };

  return {
    villes,
    ville,
    loading,
    error,
    create,
    update,
    remove,
    refetch: id ? () => fetchOne(id) : fetchAll,
  };
};
