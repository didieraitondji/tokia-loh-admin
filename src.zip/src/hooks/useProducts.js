import { useState, useEffect, useCallback } from "react";
import { productsAPI } from "../api/products.api";
import { MOCK_PRODUCTS } from "../mockData";

const USE_MOCK = false; // à Passer à false quand l'API est prête

export const useProducts = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      if (USE_MOCK) {
        await new Promise((r) => setTimeout(r, 400));
        setProducts(MOCK_PRODUCTS);
      } else {
        const { data } = await productsAPI.list();
        setProducts(data);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  const create = async (payload) => {
    if (USE_MOCK) {
      const newItem = {
        ...payload,
        id: `prod-${Date.now()}`,
        created_at: new Date().toISOString(),
        is_active: true,
      };
      setProducts((prev) => [...prev, newItem]);
      return newItem;
    }
    const { data } = await productsAPI.create(payload);
    setProducts((prev) => [...prev, data]);
    return data;
  };

  const update = async (id, payload) => {
    if (USE_MOCK) {
      setProducts((prev) =>
        prev.map((p) => (p.id === id ? { ...p, ...payload } : p)),
      );
      return { ...payload, id };
    }
    const { data } = await productsAPI.update(id, payload);
    setProducts((prev) => prev.map((p) => (p.id === id ? data : p)));
    return data;
  };

  const remove = async (id) => {
    if (USE_MOCK) {
      setProducts((prev) => prev.filter((p) => p.id !== id));
      return;
    }
    await productsAPI.delete(id);
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  return {
    products,
    loading,
    error,
    create,
    update,
    remove,
    refetch: fetchAll,
  };
};
