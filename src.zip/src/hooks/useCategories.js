import { useState, useEffect, useCallback } from "react";
import { categoriesAPI } from "../api/categories.api";
import { MOCK_CATEGORIES } from "../mockData";

const USE_MOCK = false; // à Passer à false quand l'API est prête

export const useCategories = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      if (USE_MOCK) {
        await new Promise((r) => setTimeout(r, 400));
        setCategories(MOCK_CATEGORIES);
      } else {
        const { data } = await categoriesAPI.list();
        setCategories(data);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  const create = async (payload) => {
    if (USE_MOCK) {
      const newItem = {
        ...payload,
        id: `cat-${Date.now()}`,
        is_active: true,
        created_at: new Date().toISOString(),
      };
      setCategories((prev) => [...prev, newItem]);
      return newItem;
    }
    const { data } = await categoriesAPI.create(payload);
    setCategories((prev) => [...prev, data]);
    return data;
  };

  const update = async (id, payload) => {
    if (USE_MOCK) {
      setCategories((prev) =>
        prev.map((c) => (c.id === id ? { ...c, ...payload } : c)),
      );
      return { ...payload, id };
    }
    const { data } = await categoriesAPI.update(id, payload);
    setCategories((prev) => prev.map((c) => (c.id === id ? data : c)));
    return data;
  };

  const remove = async (id) => {
    if (USE_MOCK) {
      setCategories((prev) => prev.filter((c) => c.id !== id));
      return;
    }
    await categoriesAPI.delete(id);
    setCategories((prev) => prev.filter((c) => c.id !== id));
  };

  return {
    categories,
    loading,
    error,
    create,
    update,
    remove,
    refetch: fetchAll,
  };
};
