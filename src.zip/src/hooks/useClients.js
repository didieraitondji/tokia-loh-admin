import { useState, useEffect, useCallback } from "react";
import { clientsAPI } from "../api/client.api";
import { MOCK_CLIENTS } from "../mockData";

const USE_MOCK = false; // 🔧 Passer à false quand l'API est prête

export const useClients = (id = null) => {
  const [clients, setClients] = useState([]);
  const [client, setClient] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      if (USE_MOCK) {
        await new Promise((r) => setTimeout(r, 400));
        setClients(MOCK_CLIENTS);
      } else {
        const { data } = await clientsAPI.list();
        setClients(data);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchOne = useCallback(async (clientId) => {
    setLoading(true);
    setError(null);
    try {
      if (USE_MOCK) {
        await new Promise((r) => setTimeout(r, 400));
        setClient(MOCK_CLIENTS.find((c) => c.id === clientId) ?? null);
      } else {
        const { data } = await clientsAPI.detail(clientId);
        setClient(data);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (id) fetchOne(id);
    else fetchAll();
  }, [id, fetchAll, fetchOne]);

  const verify = async (clientId) => {
    if (USE_MOCK) return { verified: true };
    const { data } = await clientsAPI.verify(clientId);
    return data;
  };

  return {
    clients,
    client,
    loading,
    error,
    verify,
    refetch: id ? () => fetchOne(id) : fetchAll,
  };
};
